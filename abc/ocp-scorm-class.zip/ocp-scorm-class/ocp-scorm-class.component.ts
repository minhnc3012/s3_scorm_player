import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ManagingClassesService } from 'app/admin';
import { OCPOnlineClass } from 'app/shared/model/ocp-online-class.model';
import { CourseScormClassService } from './ocp-scorm-class.service';
import { CourseScormResponse } from '../../shared/model/course-scorm-response.model';
import { isNullOrUndefined } from 'util';
import { DomSanitizer } from '@angular/platform-browser';
import { ThrowStmt } from '@angular/compiler';

@Component({
    selector: 'jhi-ocp-scorm-class',
    templateUrl: './ocp-scorm-class.component.html'
})
export class OCPScormClassComponent implements OnInit, OnDestroy {
    classDetails = new OCPOnlineClass();
    isFastForward = false;
    baseS3URL: string;
    playContentURL: any;
    isCompleted?: boolean;
    listener = null;
    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private managingClassesService: ManagingClassesService,
        private courseScormClassService: CourseScormClassService,
        private domSanitizer: DomSanitizer
    ) {}

    ngOnInit() {
        this.activatedRoute.params.subscribe(params => {
            const id = params['id'] ? params['id'] : null;

            if (!id) {
                this.router.navigate(['/404']);
            } else {
                this.loadData(id);
            }
        });
    }

    ngOnDestroy() {
        if (this.listener) {
            window.removeEventListener('message', this.listener, false);
        }
    }

    getBaseS3URL(url: string) {
        if (url) {
            const a = document.createElement('a');
            a.href = url;
            let origin = a.protocol + '//' + a.hostname;
            if (a.port.length > 0) {
                origin = `${origin}:${a.port}`;
            }
            //remove it
            a.remove();
            return origin;
        }
        return '';
    }

    addEventListener() {
        const self = this;
        self.listener = function(event) {
            console.log('message received:  ' + event.data, event);
            if (event && event.data && event.data.messageType) {
                if (event.data.messageType === 'PLAYER_INITIALIZED') {
                    // TODO: add a column to the class_registration record to capture CMI data.  If that is not null, send the existing data.  Otherwise, indicate it's a new run.
                    var userHasCMIDataForCourse = false;
                    var CMIData = {}; // This should be the CMI data for this user's class_registration record, if any is available.
                    if (
                        self.classDetails.classRegistrationId &&
                        self.classDetails.courseScormResponse &&
                        self.classDetails.courseScormResponse.cmiData
                    ) {
                        userHasCMIDataForCourse = true;
                        CMIData = JSON.parse(self.classDetails.courseScormResponse.cmiData);
                    }
                    if (userHasCMIDataForCourse) {
                        window.frames['scormPlayer'].contentWindow.postMessage(
                            { messageType: 'RESUME_COURSE', messageContent: CMIData },
                            self.baseS3URL
                        );
                    } else {
                        window.frames['scormPlayer'].contentWindow.postMessage(
                            { messageType: 'BEGIN_COURSE', messageContent: {} },
                            self.baseS3URL
                        );
                        self.saveCourseScormResponse(event.data.messageContent, false);
                    }
                } else if (event.data.messageType === 'STORE_COURSE_STATUS') {
                    this.console.log('Need to store the course status in class_registration');
                    // TODO: trigger a save action that will send the "messageContent" to the server.
                    self.saveCourseScormResponse(event.data.messageContent, false);
                } else if (event.data.messageType === 'TERMINATE') {
                    this.console.log('Recieved a terminate signal from the content.');
                    // TODO: trigger a save action that will send the "messageContent" to the server.
                    self.saveCourseScormResponse(event.data.messageContent, false);
                } else if (event.data.messageType === 'COURSE_COMPLETE') {
                    this.console.log('The user has completed the course content');
                    // TODO: record the users completion.  If there's an external test we may need to present that at this point.
                    window.removeEventListener('message', self.listener, false);
                    self.saveCourseScormResponse(event.data.messageContent, true);
                } else if (event.data.messageType === 'TEST_COMPLETE') {
                    this.console.log('The user has finished the test');
                    // TODO: determine whether they passed the test, record score if they passed and update status
                    // if (self.classDetails.configurationQuestionType === 'YES_TEST_COMPLETE') {
                    //     window.removeEventListener('message', self.listener, false);
                    //     self.saveCourseScormResponse(event.data.messageContent, true);
                    // } else {
                    //     self.saveCourseScormResponse(event.data.messageContent, false);
                    // }
                } else if (event.data.messageType === 'TERMINATE_PLAYBACK') {
                    window.removeEventListener('message', self.listener, false);
                    self.saveCourseScormResponse(event.data.messageContent, true);
                } else if (event.data.messageType === 'EXIT') {
                    if (event.data.messageContent && event.data.messageContent.score) {
                        const completed = event.data.messageContent.completed;
                        const score = event.data.messageContent.score;

                        if (completed) {
                            window.removeEventListener('message', self.listener, false);
                            self.saveCourseScormResponse(score.raw, true);
                        } else {
                            self.gotoDashboard();
                        }
                    } else {
                        self.gotoDashboard();
                    }
                } else {
                    this.console.log('Recieved Unknown Message Type from SCORM Player: ' + event.data.messageType);
                    // self.saveCourseScormResponse(event.data.messageContent);
                }
            }
        };
        window.addEventListener('message', self.listener, false);
    }

    loadData(id: number) {
        const self = this;
        this.managingClassesService.findOCPOnlineClass(id).subscribe(
            data => {
                this.baseS3URL = this.getBaseS3URL(data.body.playContentURL);
                this.playContentURL = this.domSanitizer.bypassSecurityTrustResourceUrl(data.body.playContentURL);
                this.classDetails = data.body;
                if (self.classDetails.classRegistrationId && self.classDetails.courseScormResponse) {
                    this.isCompleted = self.classDetails.courseScormResponse.hasCompleted;
                }

                if (!self.finishedScormPlayer()) {
                    self.addEventListener();
                }
            },
            () => {
                this.router.navigate(['/accessdenied']);
            }
        );
    }

    saveCourseScormResponse(cmiData?: any, hasCompleted?: boolean) {
        if (this.classDetails.classRegistrationId && !this.isCompleted) {
            const courseScormResponse = new CourseScormResponse();
            courseScormResponse.hasCompleted = hasCompleted;
            courseScormResponse.cmiData = JSON.stringify(cmiData);
            this.courseScormClassService.save(this.classDetails.classRegistrationId, courseScormResponse).subscribe(
                data => {
                    this.classDetails.courseScormResponse = data.body;
                    if (!this.isCompleted) {
                        this.isCompleted = hasCompleted;
                    }
                },
                () => {
                    this.router.navigate(['/404']);
                }
            );
        }
    }

    finishedScormPlayer() {
        return this.isCompleted;
    }

    rewatchPlayer() {
        this.isCompleted = null;
        this.loadData(this.classDetails.id);
    }

    gotoDashboard() {
        this.router.navigate(['/caregiver/dashboard']);
    }
}
