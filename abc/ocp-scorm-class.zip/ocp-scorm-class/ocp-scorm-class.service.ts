import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SERVER_API_URL } from 'app/app.constants';
import { ICourseScormResponse } from 'app/shared/model/course-scorm-response.model';

@Injectable({ providedIn: 'root' })
export class CourseScormClassService {
    public resourceUrl = SERVER_API_URL + 'api/course-scorm-response';

    constructor(private http: HttpClient) {}

    get(classRegistrationId: number): Observable<HttpResponse<ICourseScormResponse>> {
        return this.http.get<ICourseScormResponse>(`${this.resourceUrl}/class-registration/${classRegistrationId}`, {
            observe: 'response'
        });
    }

    save(classRegistrationId: number, courseScormResponse?: ICourseScormResponse): Observable<HttpResponse<ICourseScormResponse>> {
        return this.http.post<ICourseScormResponse>(`${this.resourceUrl}/class-registration/${classRegistrationId}`, courseScormResponse, {
            observe: 'response'
        });
    }
}
